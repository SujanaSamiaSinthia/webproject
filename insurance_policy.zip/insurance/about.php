<!DOCTYPE html>
<html>
<head>
    <title> Slogan </title>

</head>

<body>
  <h1 style ='color: #4682B4'><b> Slogan</b></h1>
  <p> “The untold stories behind your insurance policies.” </p>
<p>“We tell you the truth that your insurance agents may not tell you."</p>

</p>“We are a group of professional insurance advisors, financial planners and risk management consultants who volunteer ourselves to help you planning for your future and protect your loved ones from potential financial risks. Our advice and seminars are completely FREE. “</p>

<img src="WhatsApp Image 2022-02-06 at 1.11.15 AM (1).jpeg" width="350" height="220" alt="Insurance Policy" />


</body>

</html>
