<!DOCTYPE html>
<html>
<head>
<title> Car Rental Service</title>
<head>
<body>

<?php

    $mysqli = new mysqli("localhost", "root", "", "lab7");
    //Initializing the session
    session_start();

    //writing MySQL Query to insert the details
    $sql = "insert into orders (name,year,mileage,duration,address,timeorder) values (
                    '" . $_SESSION['name'] . "',
                    '" . $_SESSION['year'] . "',
                    '" . $_SESSION['mileage'] . "',
                    '" . $_POST['duration']. "',
                    '" . $_POST['address']. "',
                    '" . $_POST['timeorder']. "'
                    )";

    if ($mysqli->query($sql) == true)
    {
        echo "Rent Successful!\n";
        echo "<pre>\n";
        echo "Invoice";
        echo "<pre>\n";
require_once "pdo.php";
$stmt = $pdo->query("SELECT * FROM orders ORDER
BY orderId DESC
LIMIT 1");
echo '<table border="1">'."\n";
echo "<td><b>Name</b></td>"."<td> <b>Year</b></td>"."<td><b>Mileage</b></td>"."<td><b>Duration</b></td>"."<td><b>Address</b></td>"."<td><b>Time</b></td>";
while ( $row =$stmt->fetch(PDO::FETCH_ASSOC) ) {
echo "<tr><td>";
echo ($row['name']);
echo ("</td><td>");
echo ($row['year']);
echo ("</td><td>");
echo ($row['mileage']);
echo ("</td><td>");
echo ($row['duration']);
echo ("</td><td>");
echo ($row['address']);
echo ("</td><td>");
echo ($row['timeorder']);
echo ("</td></tr>");
}
echo"</table>\n";

    }
    else
    {
        echo "ERROR: Could not able to execute $sql. "
               .$mysqli->error;
    }

    // Close connection
    $mysqli->close();
?>


<button onclick="window.location.href='add.php'">Rent a New Car</button>
<button onclick="window.location.href='index.php'">Logout</button>

</body>
</html>
